---
name: presentation-modele-suez
description: Crée des présentations PowerPoint (.pptx) à partir d'un document fourni (markdown, Word, notes, spécification) en appliquant le modèle SUEZ (Modele.potx) : charte, dispositions, couleurs, polices. À utiliser dès que l'utilisateur demande une présentation, des slides, un deck ou un PowerPoint à partir d'un document, même s'il ne cite pas le modèle. Livre un .pptx modifiable dans PowerPoint ou Copilot.
---

# Présentation PowerPoint au modèle SUEZ

Transforme un document (surtout du markdown) en présentation `.pptx` mise en forme avec le modèle fourni
(`assets/Modele.potx`). Le résultat est un vrai PowerPoint : titres dans les placeholders du modèle, éléments
visuels en formes natives colorées par le thème, tableaux natifs. Tout reste modifiable à la main.

Contenu de la skill :
- `assets/Modele.potx` : le modèle (à remplacer pour changer de charte, voir « Changer de modèle »).
- `scripts/suez_pptx.py` : bibliothèque (ouvrir le modèle, créer une diapositive par disposition, cartes,
  bandeaux, chiffres clés, schémas de flux, tableaux).
- `scripts/inspect_template.py` : catalogue des dispositions + galerie visuelle d'un modèle.
- `references/layouts.md` : dispositions à utiliser, palette, zone de contenu, pièges. **À lire avant de construire.**
- `examples/build_wi219698.py` : exemple complet de 23 diapositives (couverture, sommaire, chapitres, cartes,
  tableaux, schémas, annexes). Le copier comme point de départ.

## Procédure

1. **Lire le document en entier** (`Read`), repérer : objectif, sections, tableaux, chiffres, schémas (blocs
   mermaid, images). Les images référencées par le markdown (`![](assets/…)`) ne sont en général pas jointes :
   redessiner le schéma avec les formes natives (`flow`, `zone`, `add_arrow`) ou le signaler à l'utilisateur.
2. **Construire le plan** avant de coder : un message par diapositive, titre-message court (max 2 lignes),
   structure : couverture → sommaire → (objectif/contexte) → chapitres avec leurs diapositives → recommandation
   → annexes → fin. Compter 1 diapositive par idée, pas par paragraphe. Condenser : 3 à 5 puces de 2 lignes max,
   jamais un paragraphe copié du document. Rien d'inventé : tout chiffre ou affirmation vient du document.
3. **Choisir les dispositions** (tableau dans `references/layouts.md`) et varier les formes : cartes, chiffres
   clés, tableau, flux, comparaison avantages/inconvénients, lignes numérotées. Pas deux diapositives de suite
   identiques ; pas de diapositive « titre + puces » sans élément visuel.
4. **Écrire un script Python** (partir de `examples/build_wi219698.py`) :
   ```python
   import sys; sys.path.insert(0, "<skill>/scripts")
   from suez_pptx import *
   prs = open_template("<skill>/assets/Modele.potx")      # .potx ou .pptx, diapositives d'exemple retirées
   s = new_slide(prs, "Titre seul", "Mon titre-message")   # numéro de page ajouté
   card(s, L, TOP, 6.0, 3.0, "Avantages", ["point 1", "point 2"], header=GREEN, header_color=NAVY)
   prs.save("sortie.pptx")
   ```
   Fonctions : `new_slide`, `set_text`, `ph`, `drop_empty_placeholders`, `restore_art`, `add_box`, `add_text`,
   `bullets`, `card`, `banner`, `stat`, `badge`, `numbered_row`, `flow`, `zone`, `add_arrow`, `add_table`.
   Les identifiants techniques dans un texte : run `("nom_technique", {"code": True})` (gras, 2 pt plus petit).
   Les avertissements `[ajustement ?]` à l'exécution signalent un texte probablement trop long pour sa forme.
5. **Contrôle qualité (obligatoire)** : voir plus bas. Corriger, régénérer, revérifier les diapositives modifiées.
6. **Livrer** le `.pptx` (nom explicite, ex. `Presentation_<sujet>.pptx`) avec 1 à 2 phrases : nombre de
   diapositives, choix notables, limites (schémas redessinés, incohérences relevées dans le document).

## Règles de mise en forme

- Titres : dans le placeholder (jamais une zone de texte), casse normale (le modèle met en capitales), 1 à 2 lignes,
  sans point final, même position sur toutes les diapositives de contenu.
- Textes : corps ≥ 14 pt (12 pt toléré dans les tableaux denses et les légendes), titres de cartes 15-17 pt,
  grands chiffres 26-54 pt avec `font=FONT_HEAD`. Alignement à gauche (centrer seulement titres, chiffres, nœuds de schéma).
- Couleurs : uniquement les constantes du thème (`NAVY`, `BLUE`, `ORANGE`, `GOLD`, `GREEN`, `LIGHT_*`).
  Texte marine sur fond clair/vert/orange/or ; texte blanc sur marine. Un point d'attention = orange ; composant
  nouveau = or ; cible/résultat = marine.
- Pas de bandeaux décoratifs, de filets sous les titres ni de liserés de couleur sur un bord de carte.
- Marges : rester dans x 0,47 → 12,86 et y 1,75 → 6,65 ; espacement entre blocs 0,25-0,3 ; ne rien poser sur le logo.
- Formes à coins droits (cohérent avec le modèle), sans ombre (déjà géré par la bibliothèque).
- Tableaux natifs (`add_table`), jamais une image de tableau. Schémas : formes natives, flèches reliant des boîtes.
- Éviter les cartes à moitié vides : ajuster la hauteur au contenu ou augmenter légèrement la taille du texte.

## Contrôle qualité

Utiliser la skill `pptx` pour les outils de rendu et de validation (son dossier contient `scripts/office/`) :

```bash
python3 <pptx-skill>/scripts/office/soffice.py --headless --convert-to pdf sortie.pptx
pdftoppm -jpeg -r 70 sortie.pdf slide          # puis regarder chaque image (ou des planches 2x2 avec Pillow)
python3 <pptx-skill>/scripts/office/validate.py sortie.pptx --original <Modele copié en .pptx>
markitdown sortie.pptx | grep -iE "lorem|ipsum|Cliquez|Click to|_x000B_"   # restes de modèle
```
Chercher : texte qui dépasse ou est coupé, chevauchements, cartes qui se touchent, blocs trop vides, titres à des
hauteurs différentes, coupure au milieu d'un mot ou d'un chiffre, contraste faible. Le rendu LibreOffice remplace
Arial Black : si un titre tient juste, raccourcir le titre.
Pour `--original`, copier `assets/Modele.potx` sous un nom `.pptx` (le type de contenu diffère mais la baseline reste valable).

## Changer de modèle

1. Remplacer `assets/Modele.potx` (ou passer un autre chemin à `open_template`).
2. `python3 scripts/inspect_template.py <nouveau modèle> ./inspection` → `catalogue.md` et `gallery.pptx`
   (convertir la galerie en images pour voir chaque disposition).
3. Mettre à jour `references/layouts.md` (noms de dispositions, idx des placeholders, palette) et, dans
   `suez_pptx.py`, les constantes de couleurs si les rôles du thème changent (NAVY = tx1, BLUE = accent1…).
4. Vérifier les pièges propres au nouveau modèle (placeholders à image de fond, pied de page, capitales).

## Limites connues

- Pas d'images de photo : les emplacements image du modèle sont supprimés s'ils restent vides.
- Pas de graphiques natifs dans la bibliothèque : pour un graphique, utiliser `python-pptx` (`slide.shapes.add_chart`)
  avec les couleurs du thème, ou la disposition `Graphics`.
- Dispositions des masques 1 et 2 : utilisables via `new_slide(..., master=1)`, non couvertes par `references/layouts.md`.
