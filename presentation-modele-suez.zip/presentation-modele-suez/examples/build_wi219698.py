"""Exemple complet : présentation « Alimentation temps réel ADX » (WI-219698) construite depuis le
document markdown WI-222009-real-time-adx-design-v1.4.md avec le modèle SUEZ.

Usage : python3 build_wi219698.py <Modele.potx> <sortie.pptx>
Sert de modèle de script : copier, remplacer le contenu, garder la structure (helpers de suez_pptx).
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from suez_pptx import *  # noqa: E402,F401,F403

TEMPLATE = sys.argv[1] if len(sys.argv) > 1 else "../assets/Modele.potx"
OUT = sys.argv[2] if len(sys.argv) > 2 else "presentation.pptx"

NB = " "
FOOT = None   # pied de page personnalisé possible : f"WI-219698 · … · v1.4" (le modèle a déjà son libellé)


def B(t):          # gras
    return (t, {"bold": True})


def C(t):          # identifiant technique (gras, plus petit)
    return (t, {"code": True})


prs = open_template(TEMPLATE)


def content(title):
    return new_slide(prs, "Titre seul", title, footer=FOOT)


def chapter(num, title, subtitle):
    s = new_slide(prs, "Chapter", num, footer=FOOT)
    set_text(ph(s, 13), [title])
    set_text(ph(s, 14), [subtitle])
    restore_art(s, 19)
    set_text(ph(s, 19), ["\u00a0"])  # idx 19 = motif graphique (image en fond de placeholder) : il faut un texte non vide
    drop_empty_placeholders(s)
    return s


# ------------------------------------------------------------------ 1. Couverture
s = new_slide(prs, "Diapositive de titre",
              f"Alimentation «{NB}temps réel{NB}»\vde la table ADX alr",
              slide_number=False)
set_text(ph(s, 13), ["Solutions étudiées et recommandation · WI Azure DevOps 219698\v"
                     "Version 1.4 · 19/10/2026 · Adlène BECIS, Philippe FONTAINE"])

# ------------------------------------------------------------------ 2. Sommaire
s = new_slide(prs, "Summary", "Sommaire", footer=FOOT)
set_text(ph(s, 13), [{"text": t, "size": 16, "after": 18, "hang": 0.6} for t in (
    "1.\tExistant et contraintes à respecter",
    "2.\tSolutions possibles : avantages et inconvénients",
    "3.\tSolution préconisée et décision",
    "A.\tAnnexe : le merger pseudo-delta")])

# ------------------------------------------------------------------ 3. Objectif
s = content("Passer d’une mise à jour quotidienne au quasi temps réel")
cw = 5.6
add_box(s, L, 1.8, cw, 2.15, fill=LIGHT_GREY, name="Situation actuelle", paras=[
    {"text": "AUJOURD’HUI", "bold": True, "size": 12, "after": 2},
    {"text": "Données de J-1", "size": 26, "font": FONT_HEAD, "after": 8},
    "ON’connect Revenue est mis à jour une fois par jour : les données disponibles sont celles de la veille."],
    size=14, margins=(0.25, 0.18, 0.25, 0.1))
add_arrow(s, L + cw + 0.12, 2.9, R - cw - 0.12, 2.9, color=ORANGE, width=4)
add_box(s, R - cw, 1.8, cw, 2.15, fill=LIGHT_BLUE, name="Cible", paras=[
    {"text": "CIBLE", "bold": True, "size": 12, "after": 2},
    {"text": "Quasi temps réel", "size": 26, "font": FONT_HEAD, "after": 8},
    "Une fraîcheur équivalente à celle du portail de supervision ON’connect, pour les services "
    "reposant sur des alertes (gestion des fuites)."],
    size=14, margins=(0.25, 0.18, 0.25, 0.1))
banner(s, L, 4.25, W, 2.3, "OBJECTIF DE L’ÉTUDE", [
    {"runs": ["Alimenter en quasi temps réel la table ADX des alarmes ", B("alr"),
              " à partir d’une file RabbitMQ, avec les mêmes messages et les mêmes règles pseudo-delta "
              "que le notebook Synapse ", C("emtd_dev_alr_json_to_delta_parallel"), "."], "after": 10},
    "Le document compare les solutions possibles et formule une recommandation."], size=16,
    name="Objectif")

# ------------------------------------------------------------------ 4. Chapitre 1
chapter("1.", "Existant et contraintes",
        "Chaîne actuelle, règles pseudo-delta, update policy, contrat de message")

# ------------------------------------------------------------------ 5. Chaîne actuelle
s = content("Chaîne actuelle : trois étapes, un seul déclencheur quotidien")
cw, gap = 3.93, 0.3
cols = [
    ("1", "Collecte", [
        "Les services BAPS publient les alarmes ALR dans RabbitMQ",
        "StreamSets Data Collector 3.22.3 les consomme",
        ["Dépôt de fichiers JSON dans le Datalake Synapse : ", C("raw/EMTD/ALR/INPUT")]]),
    ("2", "JSON vers Delta", [
        ["Trigger quotidien ", C("EMTD_AND_DEPENDENCIES_24H"), ", fenêtre glissante de 24 h"],
        [C("emtd_dev_alr_json_to_delta_parallel"), " (pool SparkEmtdIngest)"],
        "Aplatit data.alarms[] et dédoublonne sur transmitter + code + date",
        "Met à jour la Delta et exporte un Parquet pour ADX"]),
    ("3", "Filtre OCR et ADX", [
        [C("oc_revenue_filter_adx_client"), " : garde les transmetteurs du périmètre OCR"],
        [C("oc_revenue_alr_adx_ingestion"), " : lot déposé dans alr_tmp, puis ", C(".update table"),
         " sur alr"]]),
]
for i, (n, ttl, items) in enumerate(cols):
    x = L + i * (cw + gap)
    add_box(s, x, 1.8, cw, 3.6, fill=LIGHT_BLUE, name=f"Étape {n}")
    badge(s, x + 0.2, 1.95, 0.5, n, fill=NAVY, name=f"N° étape {n}")
    add_text(s, x + 0.85, 1.95, cw - 1.0, 0.5, [ttl], size=17, bold=True, anchor=MSO_ANCHOR.MIDDLE,
             name=f"Titre étape {n}")
    add_text(s, x + 0.2, 2.6, cw - 0.4, 2.75, bullets(items, 14), name=f"Détail étape {n}")
stat(s, L, 5.6, 2.9, 1.05, "24 h", "cadence unique", fill=NAVY, value_size=34, name="Cadence")
add_box(s, L + 3.2, 5.6, W - 3.2, 1.05, fill=LIGHT_GREY, anchor=MSO_ANCHOR.MIDDLE, size=14,
        margins=(0.25, 0.1, 0.25, 0.1), name="Conséquence cadence",
        paras=["Le trigger est partagé avec MSR et PATRIMONIO : une cadence plus fréquente suppose "
               "une chaîne ALR dédiée, avec son propre déclencheur et couvrant les étapes 2 et 3."])

# ------------------------------------------------------------------ 6. Règles pseudo-delta
s = content("Règles à conserver : le pseudo-delta")
rows = [
    [B("Aplatir "), C("data.alarms[]"), " : une ligne par alarme, avec le client et le transmetteur du message"],
    [B("Normaliser "), C("recordTs"), " : s’il est absent, il prend l’heure d’exécution du traitement"],
    [B("Calculer "), C("partDate"), " : mois de valueDate (aaaa-MM), partition de la Delta ; seuls les mois du lot sont relus"],
    [B("Dédoublonner dans le lot"), " sur transmitter + code + date, en gardant le recordTs le plus récent"],
    [B("Remplacer dans alr"), " la version existante de chaque alarme du lot, sans tenir compte du client"],
]
for i, r in enumerate(rows):
    numbered_row(s, L, 1.8 + i * 0.97, 7.7, 0.86, i + 1, r, size=14, fill=LIGHT_GREY, name=f"Règle {i + 1}")
add_box(s, 8.5, 1.8, R - 8.5, 4.75, fill=NAVY, name="Clé de remplacement", margins=(0.25, 0.2, 0.25, 0.15),
        paras=[{"text": "CLÉ DE REMPLACEMENT DANS ALR", "bold": True, "size": 12, "color": GREEN, "after": 10}],
        size=14, color=WHITE)
for j, k in enumerate(["valueDate", "transmitter", "code", "eventDate"]):
    add_box(s, 8.8, 2.55 + j * 0.62, R - 8.5 - 0.6, 0.5, fill=WHITE, anchor=MSO_ANCHOR.MIDDLE,
            paras=[{"text": k, "bold": True, "size": 14}], size=14, name=f"Clé {k}")
add_text(s, 8.8, 5.1, R - 8.5 - 0.6, 1.35, [
    {"text": "Le client n’entre jamais dans la clé, ni côté Delta, ni côté ADX.", "bold": True, "after": 6},
    "Delta : un mois (partDate) à la fois, uniquement les codes présents dans le lot."],
    size=13, color=WHITE, name="Précisions clé")

# ------------------------------------------------------------------ 7. Piège : dernière version reçue
s = content("Attention : la dernière version reçue l’emporte, pas la plus récente")
cw, gap = 3.7, (W - 3 * 3.7) / 2
steps = [
    ("SITUATION DE DÉPART", "10:00", "Version déjà présente dans alr pour une alarme (T, C, E)", LIGHT_GREY, NAVY),
    ("LOT A REÇU", "10:02", "Le lot contient 10:01 et 10:02, garde 10:02, qui remplace 10:00", LIGHT_BLUE, NAVY),
    ("LOT B REÇU PLUS TARD", "09:59", "La version en retard 09:59 remplace 10:02 : retour en arrière", ORANGE, NAVY),
]
for i, (lab, t, txt, fill, col) in enumerate(steps):
    x = L + i * (cw + gap)
    add_box(s, x, 1.8, cw, 3.2, fill=fill, name=f"Étape {i + 1}", paras=[
        {"text": lab, "bold": True, "size": 12, "color": col, "after": 4},
        {"text": "Version dans alr :", "size": 13, "color": col, "after": 0},
        {"text": t, "size": 54, "font": FONT_HEAD, "color": col, "after": 10},
        {"text": txt, "size": 15, "color": col}], size=15, margins=(0.25, 0.2, 0.25, 0.1))
    if i:
        add_arrow(s, x - gap + 0.08, 3.4, x - 0.08, 3.4, color=NAVY, width=3)
banner(s, L, 5.3, W, 1.3, "COMPORTEMENT ACTUEL : « LA DERNIÈRE VERSION REÇUE L’EMPORTE »",
       "Pour garantir « la version la plus récente l’emporte », il faudrait comparer chaque version "
       "entrante à celle déjà stockée avant de la remplacer.", size=15, name="Conséquence")

# ------------------------------------------------------------------ 8. Update policy vs .update table
s = content("Update policy et .update table : deux rôles complémentaires")
cw, gap = 3.93, 0.3
specs = [
    ("Update policy : peut couvrir", GREEN, NAVY, [
        "Lire le staging alimenté par Event Hubs",
        "Aplatir data.alarms[] et typer les colonnes",
        "Calculer partDate, appliquer le fallback recordTs",
        "Ajouter dans une table intermédiaire (append)"]),
    ("Update policy : ne couvre pas", ORANGE, NAVY, [
        "Rapprocher le lot des alarmes déjà dans alr",
        "Remplacer une alarme existante",
        "Choisir la version la plus récente (recordTs)",
        "Traiter la table mois par mois"]),
    (".update table : remplace", NAVY, WHITE, [
        "Supprime les anciennes versions et ajoute les nouvelles en une opération atomique",
        "Déjà utilisée par oc_revenue_alr_adx_ingestion",
        "Ne se lance pas seule : il faut un orchestrateur",
        "Droits Table Admin, 5 M de lignes supprimées max par commande"]),
]
for i, (ttl, hc, hcol, items) in enumerate(specs):
    card(s, L + i * (cw + gap), 1.8, cw, 3.6, ttl, items, fill=LIGHT_GREY, header=hc, header_color=hcol,
         size=14, title_size=15, name=ttl)
banner(s, L, 5.6, W, 1.05, "EN PRATIQUE",
       "Update policy pour préparer (staging typé), .update table pour remplacer dans alr (merger). "
       "Table temps réel dédiée avec arg_max(recordTs, *) à la lecture : écartée, alr reste la référence.",
       size=14, name="Positionnement")

# ------------------------------------------------------------------ 9. Contrat de message
s = content("Contrat de message et conversions à respecter")
card(s, L, 1.8, 4.4, 3.6, "Message RabbitMQ (format inchangé)", [
    "origin, type", "data.client, data.transmitter",
    "data.alarms[] : alarmCategory, code, complement, date, recordTs, value, valueDate"],
    fill=LIGHT_BLUE, size=16, title_size=17, after=10, name="Message")
add_table(s, 5.2, 1.8, [2.1, 5.59], [
    ["Champ", "Conversion à appliquer dans ADX"],
    [[{"text": "date", "bold": True}], "Converti en UTC et stocké dans eventDate (alr n’a pas de colonne date)"],
    [[{"text": "recordTs", "bold": True}], "Nombre de millisecondes converti en date-heure : unité à conserver"],
    [[{"text": "valueDate", "bold": True}], "Obligatoire ; partDate en est déduit (mois, aaaa-MM)"],
    [[{"text": "complement, value", "bold": True}], "Stockés en texte, ni objet JSON ni nombre"]],
    size=13, row_h=0.78, head_h=0.5, name="Conversions")
banner(s, L, 5.65, W, 0.95, None,
       "La nouvelle chaîne doit appliquer exactement les mêmes conversions que le notebook actuel : "
       "les règles de consolidation en dépendent.", size=15, name="Rappel")

# ------------------------------------------------------------------ 10. Chapitre 2
chapter("2.", "Solutions possibles", "Quatre options comparées : principe, avantages, inconvénients, charge")

# ------------------------------------------------------------------ 11. Vue d'ensemble
s = content("Vue d’ensemble des quatre solutions")
sol = lambda a, b: [{"text": a, "bold": True, "after": 2}, b]
add_table(s, L, 1.8, [0.5, 3.1, 3.4, 1.45, 0.95, 2.99], [
    ["#", "Solution", "Principe", "Fidélité aux règles", "Charge", "Verdict"],
    ["1", sol("Micro-batch Synapse", "RabbitMQ → StreamSets → Lake → notebooks existants → alr"),
     "On garde le notebook pseudo-delta actuel et on augmente la fréquence", "Très forte", "2 à 4 j",
     "La plus simple, mais pas du temps réel"],
    ["2", sol("Shovel + Event Hubs + merger", "RabbitMQ Shovel → Event Hubs → staging ADX → merger → alr"),
     "Le shovel transporte, ADX ingère, un merger applique le pseudo-delta", "Moyenne à forte", "8 j",
     "Bon MVP si le PoC Shovel est concluant"],
    ["3", sol("Consumer + Event Hubs + merger", "Consumer containerisé → Event Hubs → staging ADX → merger → alr"),
     "Un consumer remplace le shovel et prépare le flux proprement", "Très forte", "10 j",
     "Meilleur compromis professionnel"],
    ["4", sol("Consumer direct vers ADX", "Pseudo-delta embarqué dans l’application"),
     "L’application gère transport, dédoublonnage et écriture finale", "Forte", "15 j",
     "La moins simple, seulement si la latence prime"]],
    size=12, row_h=0.9, head_h=0.45, col_align=[PP_ALIGN.CENTER, None, None, None, PP_ALIGN.CENTER, None],
    name="Comparatif")
add_text(s, L, 6.0, W, 0.65, [
    "Charges : ordres de grandeur d’étude, hors validation infra. Variante non retenue de la solution 2 : "
    "Event Hubs → Data Connection → update policy → alr sans merger, car l’append ne remplace pas les lignes existantes."],
    size=12, name="Notes")

# ------------------------------------------------------------------ 12. Solution 1
s = content("Solution 1 : micro-batch avec le notebook Synapse existant")
flow(s, [{"label": "RabbitMQ", "fill": LIGHT_GREY},
         {"label": "StreamSets", "sub": "3.22.3", "fill": LIGHT_GREY},
         {"label": "Lake", "sub": "fichiers JSON", "fill": LIGHT_GREY},
         {"label": "Notebooks Synapse", "sub": "pseudo-delta, filtre OCR", "fill": LIGHT_BLUE},
         {"label": "ADX alr", "fill": NAVY, "color": WHITE}], L, 1.75, W, 0.8, size=13)
cw, gap = 3.93, 0.3
stat(s, L, 2.75, cw, 1.3, "28–36 min", "d’exécution des traitements actuels", name="Durée")
stat(s, L + cw + gap, 2.75, cw, 1.3, "≈ 47 min", "de bout en bout, dans le meilleur cas", name="Bout en bout")
stat(s, L + 2 * (cw + gap), 2.75, cw, 1.3, "60 → 30 min", "cadence du pilote, en séquentiel", fill=GREEN,
     value_color=NAVY, label_color=NAVY, name="Cadence pilote")
card(s, L, 4.25, 6.045, 2.4, "Avantages", [
    "Réutilisation complète des traitements existants",
    "Règles conservées : pseudo-delta, recordTs, clé transmitter + code + date",
    "Risque limité, 2 à 4 jours de charge"],
    fill=LIGHT_GREY, header=GREEN, header_color=NAVY, size=13, title_size=15, name="Avantages")
card(s, L + 6.045 + 0.3, 4.25, 6.045, 2.4, "Inconvénients", [
    "Pas de temps réel : fraîcheur de plusieurs dizaines de minutes",
    "Fréquence de 1 à 5 minutes non démontrée",
    "Dépendance à Synapse et à ses démarrages Spark"],
    fill=LIGHT_GREY, header=ORANGE, header_color=NAVY, size=13, title_size=15, name="Inconvénients")

# ------------------------------------------------------------------ 13. Solution 2
s = content("Solution 2 : Shovel, Event Hubs, staging ADX, merger")
flow(s, [{"label": "RabbitMQ", "fill": LIGHT_GREY},
         {"label": "Shovel", "sub": "AMQP 1.0", "fill": LIGHT_GREY},
         {"label": "Event Hubs", "fill": LIGHT_BLUE},
         {"label": "Staging ADX", "sub": "Data Connection", "fill": LIGHT_BLUE},
         {"label": "Merger", "sub": "à développer", "fill": ORANGE},
         {"label": "alr", "fill": NAVY, "color": WHITE}], L, 1.75, W, 0.95, gap=0.35, size=13)
card(s, L, 2.95, 6.045, 2.6, "Avantages", [
    "Peu de code sur le transport",
    "Event Hubs apporte buffer, rejeu et découplage",
    "POC rapide hors périmètre merger"],
    fill=LIGHT_GREY, header=GREEN, header_color=NAVY, size=14, title_size=15, name="Avantages")
card(s, L + 6.045 + 0.3, 2.95, 6.045, 2.6, "Inconvénients", [
    "Dépendance forte à la compatibilité Shovel AMQP 1.0 (version, TLS)",
    "Merger vers alr à développer : la Data Connection ne fait qu’ajouter des lignes",
    ["Moins de contrôle du payload : la transformation de ", C("complement"),
     " en mesure, faite par StreamSets, passe dans le merger"]],
    fill=LIGHT_GREY, header=ORANGE, header_color=NAVY, size=14, title_size=15, name="Inconvénients")
stat(s, L, 5.75, 2.9, 0.9, "8 jours", "charge estimée", value_size=26, label_size=12, name="Charge")
banner(s, L + 3.2, 5.75, W - 3.2, 0.9, None,
       "« Sans code » seulement pour le transport : acceptable pour aller vite, avec un deuxième maillon.",
       size=14, name="Verdict")

# ------------------------------------------------------------------ 14. Solution 3
s = content("Solution 3 : consumer containerisé, Event Hubs, merger")
flow(s, [{"label": "RabbitMQ", "fill": LIGHT_GREY},
         {"label": "Consumer", "sub": ".NET ou Python", "fill": GOLD},
         {"label": "Event Hubs", "fill": LIGHT_BLUE},
         {"label": "Staging ADX", "sub": "Data Connection", "fill": LIGHT_BLUE},
         {"label": "Merger", "sub": "micro-batch", "fill": ORANGE},
         {"label": "alr", "fill": NAVY, "color": WHITE}], L, 1.75, W, 0.95, gap=0.35, size=13)
card(s, L, 2.95, 6.045, 2.6, "Avantages", [
    "Meilleur contrôle des acks, retries, idempotence et observabilité",
    "Découplage propre entre on-premise et Azure",
    "Event Hubs absorbe les pointes sans reposer sur l’application seule",
    ["Le consumer remplace StreamSets, dont l’extraction de ", C("complement"), " en mesure"]],
    fill=LIGHT_GREY, header=GREEN, header_color=NAVY, size=14, title_size=15, name="Avantages")
card(s, L + 6.045 + 0.3, 2.95, 6.045, 2.6, "Inconvénients", [
    "Plus de développement que la solution 2 (10 jours contre 8)",
    "Consumer et merger à héberger et à monitorer"],
    fill=LIGHT_GREY, header=ORANGE, header_color=NAVY, size=14, title_size=15, name="Inconvénients")
stat(s, L, 5.75, 2.9, 0.9, "10 jours", "charge estimée", value_size=26, label_size=12, name="Charge")
banner(s, L + 3.2, 5.75, W - 3.2, 0.9, None,
       "Meilleur compromis professionnel : tampon rejouable, règles du notebook conservées, cible directe alr.",
       size=14, name="Verdict")

# ------------------------------------------------------------------ 15. Solution 4
s = content("Solution 4 : consumer direct vers ADX, non recommandée")
flow(s, [{"label": "RabbitMQ", "fill": LIGHT_GREY},
         {"label": "Consumer .NET / Python", "sub": "prépare, dédoublonne, filtre OCR", "fill": GOLD},
         {"label": "ADX alr", "sub": "ingestion streaming, pseudo-delta embarqué", "fill": NAVY, "color": WHITE}],
     L, 1.75, W, 0.85, gap=0.6, size=13)
cw, ch = 6.045, 1.45
facts = [
    ("Aucun tampon", "Sans Event Hubs, une panne d’ADX ou du service bloque le flux, et les messages ne se rejouent pas facilement."),
    ("Tout repose sur un seul programme", "Transport, préparation et remplacement dans alr sont dans le même code : plus de risque, maintenance plus lourde."),
    ("Un gain limité", "Le remplacement dans alr passe par .update table, dont la cadence est contrainte : le streaming n’accélère que l’arrivée en staging."),
    ("Le coût le plus élevé", "Environ 15 jours de charge, sans bénéfice net par rapport à la solution 3."),
]
for i, (t, d) in enumerate(facts):
    x = L + (i % 2) * (cw + 0.3)
    y = 2.8 + (i // 2) * (ch + 0.15)
    add_box(s, x, y, cw, ch, fill=LIGHT_ORANGE, name=t, size=14, margins=(0.25, 0.15, 0.25, 0.1),
            paras=[{"text": t, "bold": True, "size": 16, "after": 6}, d])
banner(s, L, 6.0, W, 0.65, None,
       "La solution 3 offre presque la même réactivité, avec un tampon rejouable et des rôles mieux séparés.",
       size=14, name="Verdict")

# ------------------------------------------------------------------ 16. Chapitre 3
chapter("3.", "Solution préconisée", "Architecture cible, justification, décision et phasage pour OCR")

# ------------------------------------------------------------------ 17. Architecture cible
s = content("Architecture cible : consumer, Event Hubs, staging, merger")
zone(s, L, 1.8, 4.75, 3.65, "ON-PREMISE", name="Zone On-premise")
zone(s, 5.45, 1.8, R - 5.45, 3.65, "AZURE", name="Zone Azure")
node = lambda x, y, w, h, a, b=None, fill=LIGHT_BLUE, col=NAVY, **kw: add_box(
    s, x, y, w, h, fill=fill, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, size=13,
    margins=(0.06, 0.05, 0.06, 0.05), after=2, name=a, **kw,
    paras=[{"text": a, "bold": True, "size": 13, "color": col}] + ([{"text": b, "size": 11, "color": col}] if b else []))
node(0.7, 2.75, 1.7, 1.15, "RabbitMQ", fill=WHITE)
node(2.95, 2.75, 2.05, 1.15, "Consumer applicatif", ".NET ou Python, containerisé", fill=GOLD)
node(2.95, 4.35, 2.05, 0.85, "Journal des rejets", "DLQ logique", fill=WHITE, dash=True, line=NAVY)
node(5.7, 2.75, 1.5, 1.15, "Event Hubs", fill=LIGHT_BLUE)
node(7.6, 2.75, 1.65, 1.15, "alr_staging_raw", "table de staging ADX", fill=LIGHT_BLUE)
node(9.65, 2.75, 1.5, 1.15, "Merger", "pseudo-delta", fill=ORANGE)
node(11.5, 2.75, 1.15, 1.15, "alr", fill=NAVY, col=WHITE)
node(5.7, 4.35, 1.5, 0.85, "Capture", "optionnelle", fill=WHITE, dash=True, line=NAVY)
add_arrow(s, 2.4, 3.325, 2.95, 3.325)
add_arrow(s, 5.0, 3.325, 5.7, 3.325)
add_arrow(s, 7.2, 3.325, 7.6, 3.325)
add_arrow(s, 9.25, 3.325, 9.65, 3.325)
add_arrow(s, 11.15, 3.325, 11.5, 3.325)
add_arrow(s, 3.975, 3.9, 3.975, 4.35, dash=True)
add_arrow(s, 6.45, 3.9, 6.45, 4.35, dash=True)
banner(s, L, 5.75, W, 0.9, None,
       "Cible : consumer containerisé → Event Hubs → staging ADX → merger pseudo-delta → alr",
       size=16, name="Cible")

# ------------------------------------------------------------------ 18. Pourquoi cette option
s = content("Pourquoi cette option")
cw, ch, gap = 3.93, 2.3, 0.3
why = [
    ("1. Découplage propre", "RabbitMQ, buffer Azure et consolidation vers alr évoluent indépendamment."),
    ("2. Pas de dépendance au Shovel", "La robustesse de production ne repose pas sur la compatibilité Shovel du broker."),
    ("3. Buffer managé et rejouable", "Event Hubs entre la source et ADX, avec rétention et relecture."),
    ("4. Règles pseudo-delta conservées", "Celles du notebook, sans les imposer au broker."),
    ("5. Cible directe : alr", "Pas de table parallèle dont la convergence resterait à démontrer."),
]
for i, (t, d) in enumerate(why):
    x = L + (i % 3) * (cw + gap)
    y = 1.8 + (i // 3) * (ch + 0.25)
    add_box(s, x, y, cw, ch, fill=LIGHT_BLUE, name=t, size=14, margins=(0.25, 0.2, 0.25, 0.1),
            paras=[{"text": t, "bold": True, "size": 16, "after": 8}, {"text": d, "size": 15}])
add_box(s, L + 2 * (cw + gap), 1.8 + ch + 0.25, cw, ch, fill=NAVY, name="Exploitation", size=12, color=WHITE,
        margins=(0.25, 0.2, 0.25, 0.1),
        paras=[{"text": "EXPLOITATION", "bold": True, "size": 12, "color": GREEN, "after": 6}] + bullets([
            "Consumer group dédié pour ADX", "Managed identity entre ADX et Event Hubs",
            "Supervision : consumer lag, erreurs d’ingestion, retries, volumétrie, succès du merger",
            "Capture Event Hubs si PRA ou relecture longue"], 12, after=4, color=WHITE))

# ------------------------------------------------------------------ 19. Décision et phasage
s = content("Décision proposée et phasage pour OCR")
add_table(s, L, 1.8, [4.3, 8.09], [
    ["Si la priorité est…", "Choisir"],
    [[{"text": "La simplicité maximale", "bold": True}], "Solution 1 : quasi temps réel en micro-batch, fidélité maximale aux règles"],
    [[{"text": "Le meilleur compromis pérenne", "bold": True}], "Solution 3 : consumer → Event Hubs → staging ADX → merger → alr"],
    [[{"text": "Un MVP de transport rapide", "bold": True}], "Solution 2, si le PoC Shovel est concluant et qu’un merger vers alr est ajouté"],
    [[{"text": "Une latence extrême", "bold": True}], "Solution 4, non recommandée par défaut"]],
    size=13, row_h=0.55, head_h=0.45, name="Décision")
add_box(s, L, 4.6, 7.4, 2.05, fill=NAVY, name="Phasage OCR", size=14, color=WHITE, margins=(0.25, 0.15, 0.25, 0.1),
        paras=[{"text": "POUR OCR : ARBITRAGE AF DU 02/09/2026", "bold": True, "size": 12, "color": GREEN, "after": 8},
               {"runs": [B("Étape 1 : "), "solution 1 pour le quasi temps réel"], "after": 6},
               {"runs": [B("Étape 2 : "), "instruction séparée de la solution 3 si le retour terrain justifie une fraîcheur plus courte"], "after": 6},
               "Cible fonctionnelle : alr, sans nouvelle table de faits parallèle."])
add_box(s, L + 7.4 + 0.3, 4.6, W - 7.4 - 0.3, 2.05, fill=ORANGE, name="Limite", size=14, margins=(0.25, 0.15, 0.25, 0.1),
        paras=[{"text": "LIMITE À LIRE AVANT TOUT ENGAGEMENT", "bold": True, "size": 12, "after": 8},
               "Les mesures actuelles ne prouvent pas encore que l’étape 1 atteindra la fraîcheur souhaitée."])

# ------------------------------------------------------------------ 20. Annexe : outil du merger
s = content("Annexe : l’outil du merger pseudo-delta")
flow(s, [{"label": "ScheduleTrigger", "sub": "pilote : toutes les 5 min (UTC)", "fill": LIGHT_GREY},
         {"label": "Pipeline Synapse", "sub": "EXEMPLE_ALR_MERGER, concurrency 1, retry 0", "fill": LIGHT_BLUE},
         {"label": "Activité AzureDataExplorerCommand", "sub": "paramètre MergeCommand", "fill": LIGHT_BLUE},
         {"label": "ADX", "sub": ".update table alr delete D append A", "fill": NAVY, "color": WHITE}],
     L, 1.8, W, 1.3, gap=0.5, size=13)
cw, gap = 3.93, 0.3
card(s, L, 3.35, cw, 2.05, "Solution 1", [
    ["Le notebook ", C("oc_revenue_alr_adx_ingestion"), " matérialise déjà le job de pseudo-delta"]],
    fill=LIGHT_GREY, size=14, name="Solution 1")
card(s, L + cw + gap, 3.35, cw, 2.05, "Solutions 2 et 3", [
    "Pipeline Synapse dédié avec activité AzureDataExplorerCommand",
    "La commande Kusto part vers ADX, sans pool Spark"],
    fill=LIGHT_GREY, size=14, name="Solutions 2 et 3")
card(s, L + 2 * (cw + gap), 3.35, cw, 2.05, "Alternative", [
    "Worker .NET avec le SDK Kusto, en Azure Container Apps Job",
    "Si la gestion des lots et reprises devient trop applicative"],
    fill=LIGHT_GREY, size=14, name="Alternative")
add_box(s, L, 5.65, W, 1.0, fill=LIGHT_ORANGE, name="Réserve", size=14, anchor=MSO_ANCHOR.MIDDLE,
        margins=(0.25, 0.08, 0.25, 0.08), paras=[
            "Extraits illustratifs, non déployables tels quels. MergeCommand est construite par le traitement de "
            "préparation à partir d’un lot validé, jamais acceptée depuis RabbitMQ."])

# ------------------------------------------------------------------ 21. Annexe : traitement complet
s = content("Annexe : le traitement complet du merger en cinq étapes")
steps = [
    [B("Sélectionner le prochain lot clos, complet et non traité"),
     " : référence durable, lot verrouillé pendant la consolidation, découpage par fenêtre d’arrivée ou manifeste pour garder les alarmes tardives"],
    [B("Préparer le lot"),
     " : flatten, conversions, filtre OCR (accès au référentiel des transmetteurs) et dédoublonnage ; valeurs de fallback fixées avant toute reprise"],
    [B("Remplacer par portée"),
     " : construire A (lot typé) et D (lignes de alr sur valueDate + transmitter + code + eventDate), puis ",
     C(".update table alr delete D append A"), ", client hors clé"],
    [B("Confirmer avant de marquer"),
     " : attendre le succès de chaque commande avant de marquer le lot traité ; résultat inconnu : réconcilier, puis reprendre le même lot"],
    [B("Journaliser"),
     " : lot, durée, lignes, erreurs et retard jusqu’à visibilité dans alr ; un lot vide ne provoque aucune mutation"],
]
for i, r in enumerate(steps):
    numbered_row(s, L, 1.8 + i * 0.99, W, 0.88, i + 1, r, size=14, fill=LIGHT_GREY, name=f"Étape {i + 1}")

# ------------------------------------------------------------------ 22. Annexe : sécurité, concurrence, cadence
s = content("Annexe : sécurité, concurrence et cadence")
cw, gap = 3.93, 0.3
card(s, L, 1.8, cw, 3.75, "Sécurité", [
    "Linked service ADX en identité managée, aucun secret dans la configuration",
    "Droits limités aux tables concernées, dont Table Admin pour .update table"],
    fill=LIGHT_GREY, header=NAVY, header_color=WHITE, size=15, title_size=16, name="Sécurité")
card(s, L + cw + gap, 1.8, cw, 3.75, "Concurrence", [
    "concurrency: 1 ne protège que ce pipeline : prévoir un verrou partagé avec le traitement quotidien",
    "alr_tmp : usage exclusif, après préparation complète du lot",
    "Staging isolé éventuel : schéma et cycle de vie à valider"],
    fill=LIGHT_GREY, header=ORANGE, header_color=NAVY, size=15, title_size=16, name="Concurrence")
card(s, L + 2 * (cw + gap), 1.8, cw, 3.75, "Cadence", [
    "5 minutes soutenables seulement si le cycle traite les arrivées plus vite qu’elles ne s’accumulent",
    "Surveiller la file de runs, ralentir le pilote si besoin",
    "Timeouts à régler après mesure"],
    fill=LIGHT_GREY, header=GREEN, header_color=NAVY, size=15, title_size=16, name="Cadence")
add_text(s, L, 5.8, W, 0.8, [
    "Références Microsoft relues le 18/10/2026 : activité de commande ADX dans Synapse, concurrence des pipelines, "
    "ScheduleTrigger. Elles établissent les briques de configuration, pas la performance de cet exemple dans OCR."],
    size=12, name="Références")

# ------------------------------------------------------------------ 23. Fin
s = new_slide(prs, "End page", None, slide_number=False)
set_text(ph(s, 14), ["suez.com"])

for sl in prs.slides:
    drop_empty_placeholders(sl)
prs.save(OUT)
print("OK", OUT, len(prs.slides), "diapositives")
