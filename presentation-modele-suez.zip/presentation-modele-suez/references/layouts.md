# Dispositions du modèle SUEZ (Modele.potx)

Canvas : 13,333 x 7,5 po (16:9). Trois masques : **0 = charte SUEZ officielle (à utiliser par défaut)**,
1 et 2 = variantes plus anciennes (Arial, titres plus petits ; masque 2 proche d'un thème Office).
Le catalogue complet des 61 dispositions se régénère avec `scripts/inspect_template.py`.

## Palette (thème du masque 0)

| Rôle | Constante `suez_pptx` | Valeur | Usage |
| --- | --- | --- | --- |
| Marine | `NAVY` (dk1/tx1) | 030F40 | texte, bandeaux sombres, fond des pages de titre |
| Bleu clair | `BLUE` (accent1) | 77B7FC | titres de couverture, cartes teintées (`LIGHT_BLUE`) |
| Orange | `ORANGE` (accent2) | F67536 | alertes, point d'attention, composant à développer |
| Or | `GOLD` (accent3) | FFC229 | composant nouveau / mis en avant |
| Vert SUEZ | `GREEN` (tx2/dk2) | AADC14 | libellés sur fond marine, avantages, chiffres clés |
| Gris-bleu pâle | `LIGHT_GREY` | marine à 93 % | fonds de cartes neutres, lignes zébrées |

Police : titres **Arial Black** (thème majeur, en capitales automatiquement), texte **Arial**.
Ne jamais coder une couleur en dur : utiliser les constantes (elles suivent le thème).

## Dispositions à utiliser (masque 0)

| Besoin | Disposition | Placeholders utiles | Remarques |
| --- | --- | --- | --- |
| Couverture | `Diapositive de titre` | titre, body:13 (sous-titre) | titre bleu 37 pt centré, 2 lignes max (`\v` = saut de ligne) ; mettre auteur/date/version dans le sous-titre (le ruban graphique passe sous le placeholder `dt`) |
| Couverture avec photo | `Couv 2` | ctrTitle, subTitle:1 | photo intégrée au modèle |
| Sommaire | `Summary` | titre, body:13 | bandeau orange à gauche ; lignes `"1.\tTexte"` avec `hang=0.6` ; 16 pt |
| Chapitre | `Chapter` | titre (= « 1. » en 84 pt), body:13 (titre du chapitre), body:14 (sous-titre), body:19 (motif) | appeler `restore_art(s, 19)` puis mettre `" "` dans le body:19 sinon le motif n'apparaît pas ; supprimer le reste avec `drop_empty_placeholders` |
| Sous-chapitre | `Subchapter` | idem, photo à droite | |
| Texte simple | `Titre et texte` / `Titre et contenu` | titre, body:13 / object:1 | niveaux du corps : 1 = 20 pt bleu gras capitales, 2 = 20 pt marine gras, 3 = 19 pt, 4 = 16 pt gras, 5 = 13 pt ; **pas de puces par défaut** |
| **Contenu composé (cartes, schémas, tableaux)** | **`Titre seul`** | titre | disposition la plus utilisée : titre + zone libre, on compose avec `card`, `banner`, `stat`, `flow`, `add_table`… |
| Texte + tableau | `Title, text and table` | titre, body:13 (3,6 po), tbl:19 | |
| Texte + visuel à droite | `Title, text and right visual - v1` | titre, body:13, pic:16 | visuel plein bord à droite (6,8 po) ; supprimer pic:16 si pas d'image |
| Texte + visuel à gauche | `Title, text and left visual` | pic:16, titre, body:13 | |
| 4 graphiques | `Graphics` | chart:18/20/22/24 + légendes | |
| Chiffres clés | `Key figures` | nombreux body | très contraint : préférer `stat()` sur `Titre seul` |
| Citation / exergue | `Exergue slide`, `1_Verbatim 1 - orange` | body:18 / object:13 | |
| Contact / fin | `Contact`, `End page` | body:14 | `End page` = logo + baseline ; mettre « suez.com » dans body:14 |

## Zone de contenu sur `Titre seul` (pouces)

- Titre : x 0,47 ; y 0,35 ; 12,39 x 1,18 (25 pt capitales, 1 à 2 lignes).
- **Contenu : x 0,47 → 12,86 ; y 1,75 → 6,65.** Pied de page et logo SUEZ en dessous (y > 7,0) : ne rien y mettre.
- Constantes : `L`=0,47 ; `W`=12,39 ; `TOP`=1,75 ; `BOTTOM`=6,65. Gouttière entre colonnes : 0,3.

## Pièges connus de ce modèle

- python-pptx ne copie pas numéro / pied de page / date sur la diapositive : `new_slide()` le fait (numéro par défaut).
  La classification « General » en bas à gauche vient du masque : ne pas la doubler par un pied de page.
- Les placeholders vides affichent « Cliquez pour ajouter… » à l'édition : `drop_empty_placeholders()` en fin de construction.
- `Chapter` : le motif graphique est le **fond d'image du placeholder idx 19** (voir ci-dessus).
- Les titres sont en capitales (propriété du modèle) : écrire en casse normale.
- Arial Black n'est pas rendu fidèlement par LibreOffice (contrôle visuel) : laisser de la marge sur les titres.
