"""Inspecte un modèle PowerPoint (.potx/.pptx) : catalogue des dispositions + galerie visuelle.

Usage : python3 inspect_template.py <Modele.potx> [dossier_sortie]

Produit dans le dossier de sortie (défaut : .) :
  - catalogue.md   : une ligne par disposition (masque, nom, placeholders type:idx, position du titre)
  - gallery.pptx   : une diapositive par disposition, chaque placeholder étiqueté « masque | disposition | type idx »
Pour voir la galerie : la convertir en PDF puis en images (voir SKILL.md, section Contrôle qualité).
À relancer chaque fois que le modèle change, puis mettre à jour references/layouts.md.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from suez_pptx import open_template  # noqa: E402


def label(ph):
    t = str(ph.placeholder_format.type).split(".")[-1].split(" ")[0].lower()
    return f"{t}:{ph.placeholder_format.idx}"


def main(path, out="."):
    os.makedirs(out, exist_ok=True)
    prs = open_template(path)
    rows = ["| Masque | N° | Disposition | Placeholders (type:idx) |", "| --- | --- | --- | --- |"]
    n = 0
    for mi, master in enumerate(prs.slide_masters):
        for li, lay in enumerate(master.slide_layouts):
            phs = ", ".join(label(p) for p in lay.placeholders)
            rows.append(f"| {mi} | {li} | {lay.name} | {phs} |")
            s = prs.slides.add_slide(lay)
            n += 1
            for p in s.placeholders:
                try:
                    if p.has_text_frame:
                        p.text_frame.text = f"M{mi} | {lay.name} | {label(p)}"
                except Exception:
                    pass
    with open(os.path.join(out, "catalogue.md"), "w", encoding="utf8") as f:
        f.write("\n".join(rows) + "\n")
    prs.save(os.path.join(out, "gallery.pptx"))
    print(f"{n} dispositions -> {out}/catalogue.md et {out}/gallery.pptx")
    print(f"Dimensions : {prs.slide_width / 914400:.2f} x {prs.slide_height / 914400:.2f} po")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".")
