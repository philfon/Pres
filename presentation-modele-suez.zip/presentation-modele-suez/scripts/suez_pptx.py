"""suez_pptx : bibliothèque d'aide pour produire des présentations à partir du modèle SUEZ (Modele.potx).

Principes
- On ouvre le modèle (.potx ou .pptx), on supprime ses diapositives d'exemple, puis on crée des
  diapositives à partir de ses *dispositions* (masque 1 = charte SUEZ officielle).
- Titres et textes principaux : placeholders de la disposition (mise en forme héritée du modèle).
- Éléments visuels (cartes, bandeaux, tableaux, schémas) : formes natives PowerPoint colorées avec les
  couleurs du THÈME (jamais de couleurs codées en dur) => elles suivent un changement de modèle.

Usage minimal
    import sys; sys.path.insert(0, "<dossier de la skill>/scripts")
    from suez_pptx import *
    prs = open_template("<skill>/assets/Modele.potx")
    s = new_slide(prs, "Titre seul", "Mon titre", footer="Mon document · v1.0")
    card(s, L, TOP, 4, 3, "Titre de carte", ["point 1", "point 2"])
    prs.save("sortie.pptx")

Toutes les dimensions sont en pouces. Canvas du modèle : 13,333 x 7,5.
"""
import copy
import io
import math
import zipfile

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR as TC
from pptx.enum.lang import MSO_LANGUAGE_ID
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE, PP_PLACEHOLDER
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

# --------------------------------------------------------------------------- couleurs (thème)
NAVY, WHITE, GREEN, YELLOW = TC.TEXT_1, TC.BACKGROUND_1, TC.TEXT_2, TC.BACKGROUND_2
BLUE, ORANGE, GOLD = TC.ACCENT_1, TC.ACCENT_2, TC.ACCENT_3
LIGHT_BLUE = (BLUE, 0.8)
LIGHT_ORANGE = (ORANGE, 0.75)
LIGHT_GREEN = (GREEN, 0.7)
LIGHT_GREY = (NAVY, 0.93)
_SCHEME = {NAVY: "tx1", WHITE: "bg1", GREEN: "tx2", YELLOW: "bg2",
           BLUE: "accent1", ORANGE: "accent2", GOLD: "accent3"}

# --------------------------------------------------------------------------- gabarit (pouces)
SLIDE_W, SLIDE_H = 13.333, 7.5
L = 0.47                 # marge gauche des placeholders du modèle
W = 12.39                # largeur utile
R = L + W                # bord droit utile
TOP = 1.75               # début de la zone de contenu sous le titre
BOTTOM = 6.65            # fin de la zone de contenu (le pied de page est à 7.1)
FONT_HEAD = "+mj-lt"     # police de titre du thème (Arial Black)
FONT_BODY = "+mn-lt"     # police de texte du thème (Arial)


# =========================================================================== ouverture du modèle
def open_template(path, keep_slides=False):
    """Ouvre un .potx/.pptx. Convertit le type de contenu (.potx -> présentation) et retire les
    diapositives d'exemple. Le fichier enregistré est un vrai .pptx."""
    buf = io.BytesIO()
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "[Content_Types].xml":
                data = data.replace(b"presentationml.template.main+xml",
                                    b"presentationml.presentation.main+xml")
            zout.writestr(item, data)
    buf.seek(0)
    prs = Presentation(buf)
    if not keep_slides:
        lst = prs.slides._sldIdLst
        for sld in list(lst):
            prs.part.drop_rel(sld.rId)
            lst.remove(sld)
    return prs


def get_layout(prs, name, master=0):
    for lay in prs.slide_masters[master].slide_layouts:
        if lay.name == name:
            return lay
    names = [l.name for l in prs.slide_masters[master].slide_layouts]
    raise KeyError(f"Disposition '{name}' introuvable dans le masque {master} : {names}")


_PH = {"sldNum": PP_PLACEHOLDER.SLIDE_NUMBER, "ftr": PP_PLACEHOLDER.FOOTER, "dt": PP_PLACEHOLDER.DATE}


def clone_placeholder(slide, kind, text=None):
    """Copie le pied de page / numéro / date de la disposition sur la diapositive (python-pptx ne
    le fait pas). La géométrie est héritée de la disposition."""
    for ph in slide.slide_layout.placeholders:
        if ph.placeholder_format.type == _PH[kind]:
            el = copy.deepcopy(ph._element)
            sppr = el.find(qn("p:spPr"))
            for ch in list(sppr):
                sppr.remove(ch)
            sppr.attrib.clear()
            cnv = el.find(".//" + qn("p:cNvPr"))
            for ext in cnv.findall(qn("a:extLst")):
                cnv.remove(ext)
            tree = slide.shapes._spTree
            cnv.set("id", str(max(int(i) for i in tree.xpath(".//p:cNvPr/@id")) + 1))
            if text is not None:
                body = el.find(qn("p:txBody"))
                for p in body.findall(qn("a:p")):
                    body.remove(p)
                p = etree.SubElement(body, qn("a:p"))
                if kind == "ftr":                 # la date garde l'alignement de la disposition
                    etree.SubElement(p, qn("a:pPr")).set("algn", "l")
                r = etree.SubElement(p, qn("a:r"))
                etree.SubElement(r, qn("a:rPr")).set("lang", "fr-FR")
                etree.SubElement(r, qn("a:t")).text = text
            tree.append(el)
            return el
    return None


def new_slide(prs, layout, title=None, footer=None, master=0, slide_number=True, date=None):
    """Crée une diapositive depuis une disposition (par son nom). `title` remplit le placeholder de
    titre ; '\\v' = saut de ligne dans le titre. Ajoute numéro et pied de page."""
    s = prs.slides.add_slide(get_layout(prs, layout, master))
    if title is not None and s.shapes.title is not None:
        set_text(s.shapes.title, [title])
    if slide_number:
        clone_placeholder(s, "sldNum")
    if footer:
        clone_placeholder(s, "ftr", footer)
    if date:
        clone_placeholder(s, "dt", date)
    return s


def ph(slide, idx):
    """Placeholder par son idx (voir references/layouts.md)."""
    return slide.placeholders[idx]


def restore_art(slide, idx):
    """Certains placeholders de la disposition (ex. « Chapter » idx 19) portent un MOTIF en image de fond.
    Une diapositive ne le montre pas toujours (placeholder vide) : on recopie explicitement le fond
    (image + géométrie) sur la diapositive. À utiliser avec un texte non vide (ex. '\\u00a0')."""
    lay = slide.slide_layout
    src = next(p for p in lay.placeholders if p.placeholder_format.idx == idx)
    dst = slide.placeholders[idx]
    sp_src = src._element.find(qn("p:spPr"))
    blip = sp_src.find(qn("a:blipFill"))
    if blip is None:
        return
    rid = blip.find(qn("a:blip")).get(qn("r:embed"))
    _, new_rid = slide.part.get_or_add_image_part(io.BytesIO(lay.part.related_part(rid).blob))
    new = copy.deepcopy(sp_src)
    new.find(qn("a:blipFill")).find(qn("a:blip")).set(qn("r:embed"), new_rid)
    old = dst._element.find(qn("p:spPr"))
    dst._element.replace(old, new)


def drop_empty_placeholders(slide, keep_idx=()):
    """Supprime les placeholders restés vides (sinon invite « Cliquez pour ajouter… » à l'édition)."""
    for p in list(slide.placeholders):
        if p.placeholder_format.type in _PH.values() or p.placeholder_format.idx in keep_idx:
            continue
        # l'espace insécable (\u00a0) compte comme un contenu : voir restore_art
        empty = (not p.has_text_frame) or p.text_frame.text.strip(" \t\r\n\v") == ""
        if empty:
            p._element.getparent().remove(p._element)


# =========================================================================== couleurs / texte
def _apply(cf, spec):
    if spec is None:
        return
    if isinstance(spec, str):
        cf.rgb = RGBColor.from_string(spec.lstrip("#"))
        return
    theme, br = (spec if isinstance(spec, tuple) else (spec, 0))
    cf.theme_color = theme
    if br:
        cf.brightness = br


def _runs_of(spec):
    if isinstance(spec, str):
        return [(spec, {})]
    if isinstance(spec, dict):
        if "runs" in spec:
            return [(r, {}) if isinstance(r, str) else r for r in spec["runs"]]
        return [(spec.get("text", ""), {})]
    return [(r, {}) if isinstance(r, str) else r for r in spec]


def _bullet(p, char="•", indent=0.2, color=ORANGE):
    ppr = p._p.get_or_add_pPr()
    ppr.set("marL", str(int(Inches(indent))))
    ppr.set("indent", str(-int(Inches(indent))))
    for tag in ("a:buNone", "a:buChar", "a:buAutoNum", "a:buFont", "a:buClr"):
        for e in ppr.findall(qn(tag)):
            ppr.remove(e)
    clr = etree.SubElement(ppr, qn("a:buClr"))
    etree.SubElement(clr, qn("a:schemeClr")).set("val", _SCHEME.get(color, "accent2"))
    etree.SubElement(ppr, qn("a:buFont")).set("typeface", "Arial")
    etree.SubElement(ppr, qn("a:buChar")).set("char", char)


def fill_paras(tf, paras, size=None, color=None, bold=None, align=None, after=None, font=None):
    """Remplit un text_frame. `paras` = liste de paragraphes ; chaque paragraphe est :
       - une str ;
       - une liste de runs [str | (str, {bold,size,color,italic,font,code})] ;
       - un dict {text|runs, bullet, indent, size, bold, color, align, after, before, font}.
       Un run {'code': True} met un identifiant technique en gras, 2 pt plus petit."""
    if isinstance(paras, (str, dict)):
        paras = [paras]
    tf.clear()
    for i, spec in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        opts = spec if isinstance(spec, dict) else {}
        al = opts.get("align", align)
        if al is not None:
            p.alignment = al
        af = opts.get("after", after)
        if af is not None:
            p.space_after = Pt(af)
        if opts.get("before") is not None:
            p.space_before = Pt(opts["before"])
        if opts.get("bullet"):
            _bullet(p, opts["bullet"] if isinstance(opts["bullet"], str) else "•",
                    opts.get("indent", 0.2), opts.get("bullet_color", ORANGE))
        if opts.get("hang"):      # retrait suspendu (listes numérotées « 1.<tab>texte »)
            ppr = p._p.get_or_add_pPr()
            ppr.set("marL", str(int(Inches(opts["hang"]))))
            ppr.set("indent", str(-int(Inches(opts["hang"]))))
        for text, fmt in _runs_of(spec):
            for k, part in enumerate(text.split("\v")):     # '\v' = saut de ligne
                if k:
                    p.add_line_break()
                if part == "":
                    continue
                r = p.add_run()
                r.text = part
                f = r.font
                r.font.language_id = MSO_LANGUAGE_ID.FRENCH
                psize = fmt.get("size", opts.get("size", size))
                if fmt.get("code") and psize:
                    psize -= 2
                if psize:
                    f.size = Pt(psize)
                b = fmt.get("bold", opts.get("bold", bold))
                if fmt.get("code"):
                    b = True
                if b is not None:
                    f.bold = b
                if fmt.get("italic"):
                    f.italic = True
                fn = fmt.get("font", opts.get("font", font))
                if fn:
                    f.name = fn
                _apply(f.color, fmt.get("color", opts.get("color", color)))


def set_text(shape, paras, **kw):
    """Remplit un placeholder (garde la mise en forme du modèle : pas de taille/couleur forcée)."""
    fill_paras(shape.text_frame, paras, **kw)


def _estimate(paras, width, size, bold, after):
    """Hauteur approximative (po) d'un texte, pour détecter les débordements."""
    if isinstance(paras, (str, dict)):
        paras = [paras]
    total = 0.0
    for spec in paras:
        opts = spec if isinstance(spec, dict) else {}
        runs = _runs_of(spec)
        ps = opts.get("size", size)
        txt = "".join(t for t, _ in runs)
        pb = opts.get("bold", bold)
        avail = max(width - (opts.get("indent", 0.2) if opts.get("bullet") else 0), 0.3)
        cpl = max(1, int(avail / (ps * (0.57 if pb else 0.5) / 72)))
        lines = sum(max(1, math.ceil(len(seg) / cpl)) for seg in txt.split("\v"))
        total += lines * ps * 1.2 / 72 + opts.get("after", after) / 72
    return total


def _check_fit(name, paras, w, h, size, bold, after, margins):
    need = _estimate(paras, w - margins[0] - margins[2], size, bold, after) + margins[1] + margins[3]
    if need > h * 1.02:
        print(f"[ajustement ?] {name or 'texte'} : ~{need:.2f} po nécessaires pour {h:.2f} po disponibles")


# =========================================================================== formes de base
def _strip_style(shape):
    """Retire <p:style> (références de thème : ombre, contour, police blanche) d'une forme."""
    st = shape._element.find(qn("p:style"))
    if st is not None:
        shape._element.remove(st)


def add_box(slide, x, y, w, h, fill=None, line=None, line_w=1.0, shape=MSO_SHAPE.RECTANGLE,
            paras=None, size=14, color=NAVY, bold=False, align=PP_ALIGN.LEFT,
            anchor=MSO_ANCHOR.TOP, margins=(0.15, 0.1, 0.15, 0.1), after=6, name=None, dash=False):
    """Rectangle/ovale/etc. avec texte optionnel. Pas d'ombre ni de contour par défaut."""
    sh = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if name:
        sh.name = name
    _strip_style(sh)          # sinon le thème ajoute ombre et contour
    if fill is None:
        sh.fill.background()
    else:
        sh.fill.solid()
        _apply(sh.fill.fore_color, fill)
    if line is None:
        sh.line.fill.background()
    else:
        sh.line.width = Pt(line_w)
        _apply(sh.line.color, line)
        if dash:
            from pptx.enum.dml import MSO_LINE
            sh.line.dash_style = MSO_LINE.DASH
    tf = sh.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left, tf.margin_top = Inches(margins[0]), Inches(margins[1])
    tf.margin_right, tf.margin_bottom = Inches(margins[2]), Inches(margins[3])
    tf.vertical_anchor = anchor
    if paras is not None:
        fill_paras(tf, paras, size=size, color=color, bold=bold, align=align, after=after)
        _check_fit(name, paras, w, h, size, bold, after, margins)
    return sh


def add_text(slide, x, y, w, h, paras, size=14, color=NAVY, bold=False, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, margins=(0.0, 0.0, 0.0, 0.0), after=6, name=None):
    """Zone de texte sans fond."""
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    if name:
        tb.name = name
    tf = tb.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left, tf.margin_top = Inches(margins[0]), Inches(margins[1])
    tf.margin_right, tf.margin_bottom = Inches(margins[2]), Inches(margins[3])
    tf.vertical_anchor = anchor
    fill_paras(tf, paras, size=size, color=color, bold=bold, align=align, after=after)
    _check_fit(name, paras, w, h, size, bold, after, margins)
    return tb


def bullets(items, size=None, after=6, color=None, indent=0.2):
    """Transforme une liste d'éléments (str | liste de runs) en paragraphes à puces."""
    out = []
    for it in items:
        d = {"runs": _runs_of(it), "bullet": True, "after": after, "indent": indent}
        if size:
            d["size"] = size
        if color is not None:
            d["color"] = color
        out.append(d)
    return out


def add_arrow(slide, x1, y1, x2, y2, color=NAVY, width=1.75, head=True, dash=False):
    c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    _strip_style(c)
    c.line.width = Pt(width)
    _apply(c.line.color, color)
    if dash:
        from pptx.enum.dml import MSO_LINE
        c.line.dash_style = MSO_LINE.DASH
    if head:
        ln = c.line._get_or_add_ln()
        tail = etree.SubElement(ln, qn("a:tailEnd"))
        tail.set("type", "triangle")
        tail.set("w", "med")
        tail.set("len", "med")
    return c


# =========================================================================== composants
def card(slide, x, y, w, h, title, items=None, fill=LIGHT_BLUE, title_color=NAVY, size=14,
         header=None, header_color=WHITE, as_bullets=True, after=6, title_size=None, name=None):
    """Carte : fond teinté + titre gras + puces. `header` = couleur du thème => bandeau de titre."""
    tsize = title_size or size + 2
    paras = bullets(items, size, after) if (items and as_bullets) else (items or [])
    if header is None:
        body = [{"text": title, "bold": True, "size": tsize, "color": title_color, "after": 8}] + paras
        return add_box(slide, x, y, w, h, fill=fill, paras=body, size=size, name=name)
    hh = 0.6
    add_box(slide, x, y, w, hh, fill=header, anchor=MSO_ANCHOR.MIDDLE,
            paras=[{"text": title, "bold": True, "size": tsize, "color": header_color}],
            size=tsize, name=(name + " (titre)") if name else None)
    return add_box(slide, x, y + hh, w, h - hh, fill=fill, paras=paras, size=size, after=after,
                   margins=(0.15, 0.15, 0.15, 0.1), name=name)


def banner(slide, x, y, w, h, heading, paras, fill=NAVY, color=WHITE, heading_color=GREEN, size=14,
           name=None):
    body = []
    if heading:
        body.append({"text": heading, "bold": True, "size": size - 1, "color": heading_color, "after": 4})
    body += (paras if isinstance(paras, list) else [paras])
    return add_box(slide, x, y, w, h, fill=fill, paras=body, size=size, color=color,
                   anchor=MSO_ANCHOR.MIDDLE, margins=(0.25, 0.12, 0.25, 0.12), name=name)


def stat(slide, x, y, w, h, value, label, fill=NAVY, value_color=GREEN, label_color=WHITE,
         value_size=36, label_size=13, name=None):
    """Chiffre clé : grande valeur (police de titre) + libellé."""
    return add_box(slide, x, y, w, h, fill=fill, anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER,
                   paras=[{"text": value, "size": value_size, "color": value_color, "font": FONT_HEAD, "after": 2},
                          {"text": label, "size": label_size, "color": label_color}],
                   size=label_size, margins=(0.15, 0.08, 0.15, 0.08), name=name)


def badge(slide, x, y, d, text, fill=NAVY, color=WHITE, size=16, name=None):
    return add_box(slide, x, y, d, d, fill=fill, shape=MSO_SHAPE.OVAL, align=PP_ALIGN.CENTER,
                   anchor=MSO_ANCHOR.MIDDLE, margins=(0, 0, 0, 0), after=0, name=name,
                   paras=[{"text": str(text), "bold": True, "size": size, "color": color}], size=size)


def numbered_row(slide, x, y, w, h, n, runs, size=14, badge_fill=NAVY, badge_color=WHITE,
                 fill=None, name=None):
    """Ligne « pastille numérotée + texte »."""
    d = min(0.55, h)
    if fill is not None:
        add_box(slide, x, y, w, h, fill=fill, name=(name + " (fond)") if name else None)
    badge(slide, x + 0.1, y + (h - d) / 2, d, n, badge_fill, badge_color, name=(name + " (n°)") if name else None)
    return add_text(slide, x + d + 0.3, y, w - d - 0.45, h, [{"runs": _runs_of(runs)}], size=size,
                    anchor=MSO_ANCHOR.MIDDLE, after=0, name=name)


def flow(slide, items, x, y, w, h, gap=0.45, size=13, arrow_color=NAVY, name="Flux"):
    """Rangée de boîtes reliées par des flèches. items = [{label, sub, fill, color}]."""
    n = len(items)
    bw = (w - gap * (n - 1)) / n
    boxes = []
    for i, it in enumerate(items):
        bx = x + i * (bw + gap)
        paras = [{"text": it["label"], "bold": True, "size": size, "color": it.get("color", NAVY), "after": 2}]
        if it.get("sub"):
            paras.append({"text": it["sub"], "size": size - 2, "color": it.get("color", NAVY)})
        boxes.append(add_box(slide, bx, y, bw, h, fill=it.get("fill", LIGHT_BLUE), paras=paras,
                             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, size=size,
                             margins=(0.08, 0.05, 0.08, 0.05), after=2, name=f"{name} {i + 1}",
                             line=it.get("line"), dash=it.get("dash", False)))
        if i:
            add_arrow(slide, bx - gap + 0.05, y + h / 2, bx - 0.05, y + h / 2, color=arrow_color)
    return boxes


def zone(slide, x, y, w, h, label, fill=LIGHT_GREY, label_color=NAVY, name=None):
    """Zone de regroupement (ex. On-premise / Azure) avec son étiquette en haut à gauche."""
    return add_box(slide, x, y, w, h, fill=fill, name=name or f"Zone {label}",
                   paras=[{"text": label, "bold": True, "size": 12, "color": label_color}], size=12,
                   margins=(0.15, 0.08, 0.15, 0.05))


# =========================================================================== tableau natif
def _cell_borders(cell, bottom=BLUE, w=9525):
    tcpr = cell._tc.get_or_add_tcPr()
    for tag in ("a:lnL", "a:lnR", "a:lnT", "a:lnB"):
        for e in tcpr.findall(qn(tag)):
            tcpr.remove(e)
    els = []
    for tag in ("a:lnL", "a:lnR", "a:lnT"):
        e = etree.Element(qn(tag))
        e.set("w", "0")
        etree.SubElement(e, qn("a:noFill"))
        els.append(e)
    b = etree.Element(qn("a:lnB"))
    b.set("w", str(w))
    b.set("cap", "flat")
    b.set("cmpd", "sng")
    b.set("algn", "ctr")
    sf = etree.SubElement(b, qn("a:solidFill"))
    etree.SubElement(sf, qn("a:schemeClr")).set("val", _SCHEME.get(bottom, "accent1"))
    etree.SubElement(b, qn("a:prstDash")).set("val", "solid")
    els.append(b)
    for i, e in enumerate(els):          # les bordures doivent précéder le remplissage dans tcPr
        tcpr.insert(i, e)


def add_table(slide, x, y, col_w, rows, size=12, header=True, row_h=0.6, head_h=0.45,
              header_fill=NAVY, header_color=WHITE, zebra=LIGHT_GREY, col_align=None,
              first_col_bold=False, name="Tableau"):
    """Tableau natif. rows = liste de lignes ; une cellule = str | liste de paragraphes.
    row_h peut être un nombre ou une liste (hauteur par ligne, en-tête compris)."""
    nr, nc = len(rows), len(col_w)
    heights = [(head_h if (header and i == 0) else (row_h[i] if isinstance(row_h, list) else row_h))
               for i in range(nr)]
    gs = slide.shapes.add_table(nr, nc, Inches(x), Inches(y), Inches(sum(col_w)), Inches(sum(heights)))
    gs.name = name
    tbl = gs.table
    tbl.first_row = bool(header)
    tbl.horz_banding = False
    for j, wid in enumerate(col_w):
        tbl.columns[j].width = Inches(wid)
    for i, hgt in enumerate(heights):
        tbl.rows[i].height = Inches(hgt)
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = tbl.cell(i, j)
            head = header and i == 0
            cell.fill.solid()
            _apply(cell.fill.fore_color, header_fill if head else (zebra if (zebra and i % 2 == 0) else WHITE))
            cell.margin_left = cell.margin_right = Inches(0.1)
            cell.margin_top = cell.margin_bottom = Inches(0.05)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            paras = val if isinstance(val, list) else [val]
            al = (col_align[j] if col_align else None)
            fill_paras(cell.text_frame, paras, size=size,
                       color=header_color if head else NAVY,
                       bold=True if (head or (first_col_bold and j == 0)) else False,
                       align=al, after=0)
            _cell_borders(cell)
    return gs
